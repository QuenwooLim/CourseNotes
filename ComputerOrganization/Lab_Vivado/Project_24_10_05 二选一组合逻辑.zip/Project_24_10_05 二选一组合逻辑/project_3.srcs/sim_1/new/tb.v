`timescale 1ns / 10ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2024/10/15 10:43:50
// Design Name: 
// Module Name: tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module fn_sw_tb;

reg a,b,sel;//���붨��Ϊreg
wire y;//�������Ϊwire

fn_sw fn_sw(//����������ʽ
.a(a),
.b(b),
.sel(sel),
.y(y)
    );

initial begin
      a<=0;b<=0;sel<=0;//0sʱ
  #10 a<=0;b<=0;sel<=1;//10ns��
  #10 a<=0;b<=1;sel<=0;//10ns��
  #10 a<=0;b<=1;sel<=1;//10ns��
  #10 a<=1;b<=0;sel<=0;//10ns��
  #10 a<=1;b<=0;sel<=1;//10ns��
  #10 a<=1;b<=1;sel<=0;//10ns��
  #10 a<=1;b<=1;sel<=1;//10ns��
  #10 $stop;//verilogϵͳ����
  end
  
endmodule
