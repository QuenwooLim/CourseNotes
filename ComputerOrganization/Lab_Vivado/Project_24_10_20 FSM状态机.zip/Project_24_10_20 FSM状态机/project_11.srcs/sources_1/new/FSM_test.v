`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2024/10/17 10:19:10
// Design Name: 
// Module Name: FSM_test
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
module sequence_detector (
    input wire clk,      // ʱ���ź�
    input wire reset,    // �첽��λ�ź�
    input wire in,       // �����ź� in
    output reg out       // ����ź� out
);

localparam      STATE_S=3'd0,
                STATE_A=3'd1,
                STATE_B=3'd2,
                STATE_C=3'd3,
                STATE_D=3'd4;
                
reg[2:0] state,
         nxtState;

    // ״̬�Ĵ�������ʱ�������ػ�λ�ź���Чʱ���µ�ǰ״̬
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            state <= STATE_S; // ��λʱ���� IDLE ״̬
        end else begin
            state <= nxtState; // ����ת�Ƶ���һ״̬              
       end
    end
  

    // ��һ״̬�߼������ݵ�ǰ״̬�������źž�����һ״̬
    always @(*) begin
        case(state)
            STATE_S: begin
                if (in)
                    nxtState = STATE_A; // �����S״̬�յ� 1�źţ�ת��A״̬
                else
                    nxtState = STATE_S;        // ���򱣳�S״̬
            end
            STATE_A: begin
                if (in)
                    nxtState = STATE_A;     
                else
                    nxtState = STATE_B;   
            end
            STATE_B: begin
                if (in)
                    nxtState = STATE_C;    
                else
                    nxtState = STATE_S; 
            end
            STATE_C: begin
                if (in)
                    nxtState = STATE_D;   
                else
                    nxtState = STATE_B;  
            end
            STATE_D: begin
                if (in)
                      nxtState = STATE_A;     
                else
                    nxtState = STATE_B;     
            end
            default: begin
                nxtState = STATE_S;             // Ĭ��ת��S
            end
        endcase
    end
    
//״̬���
always @(posedge clk or posedge reset) begin
    if(reset) begin
    out<=0;
    end
    else if(nxtState==STATE_D) begin
    out<=1;
    end
    else begin
    out<=0;
    end
end

endmodule
